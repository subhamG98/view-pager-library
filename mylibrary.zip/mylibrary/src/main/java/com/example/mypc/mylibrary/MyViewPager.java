package com.example.mypc.mylibrary;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by my pc on 04-09-2016.
 */
public class MyViewPager extends LinearLayout{

    static int noofsize=1;
    static ViewPager myPager = null;
    static int count = 0;
    static Timer timer;



    public MyViewPager(Context context) {
        super(context);
    }


    public MyViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize(context);
    }



    public static void setTotalPages(Integer i){
        noofsize=i;
        Log.i("checkkareo", "a-" + noofsize);

    }

    public static Integer getTotalPages(){
        Log.i("checkkareo1", "a-" + noofsize);

        return noofsize;

    }
    public static void startViewPager(final Activity a){

        timer  = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (count <= getTotalPages()) {
                            Log.i("checkkareo12", "a-" + count);

                            myPager.setCurrentItem(count);
                            count++;
                        } else {
                            count = 0;
                            myPager.setCurrentItem(count);
                        }
                    }
                });
            }
        }, 100, 3000);

    }




    private void initialize(final Context context){
        inflate(context, R.layout.myviewpager, this);
        //ViewPager Adapter to set image
     /*   ViewPagerAdapter adapter = new ViewPagerAdapter(context.getApplicationContext(),getTotalPages());
        myPager = (ViewPager)findViewById(R.id.reviewpager);
        myPager.setAdapter(adapter);
        myPager.setCurrentItem(0);
*/




    }



















}
