package com.example.mypc.mylibrary;

import android.app.Activity;
import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by my pc on 04-09-2016.
 */
public class MyView extends LinearLayout {
    static int noofsize=1;
    static ViewPager myPager = null;
    static int count = 0;
    static Timer timer;



    static TextView change;
    public MyView(Context context) {
        super(context);
        initialize(context);

    }

    public MyView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize(context);
    }
    private void initialize(Context context){
        inflate(context, R.layout.myviewpager, this);
        //change=(TextView)findViewById(R.id.changetext);
        myPager = (ViewPager)findViewById(R.id.reviewpager);

    }


    public static Integer getTotalPages(){
        Log.i("checkkareo1", "a-" + noofsize);

        return noofsize;

    }


    public static void addViewPager(Integer noofpages,final Activity a,int[] imageid,int speed,int delay){
        noofsize=noofpages;
        Log.i("checkkareo", "a-" + noofsize);
        ViewPagerAdapter adapter = new ViewPagerAdapter(a,getTotalPages(),imageid);
        myPager.setAdapter(adapter);
        myPager.setCurrentItem(2);


        timer  = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (count <= getTotalPages()) {
                            Log.i("checkkareo12", "a-" + count);

                            myPager.setCurrentItem(count);
                            count++;
                        } else {
                            count = 0;
                            myPager.setCurrentItem(count);
                        }
                    }
                });
            }
        }, speed, delay);


    }









}